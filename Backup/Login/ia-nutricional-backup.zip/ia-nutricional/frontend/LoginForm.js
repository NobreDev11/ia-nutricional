import React from 'react';
function LoginForm() { return <form>Login</form>; }
export default LoginForm;